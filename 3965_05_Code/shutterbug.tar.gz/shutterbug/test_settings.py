SQLALCHEMY_DATABASE_URI = 'sqlite:////tmp/test_shutterbug.db'
SECRET_KEY = b"\x98\x9e\xbaP'D\x03\xf5\x91u5G\x1f\xbb.\x12d\x03\x80I\xb9f\x14\xd6"
DEBUG = True
UPLOAD_FOLDER = '/tmp/'
TESTING = True
