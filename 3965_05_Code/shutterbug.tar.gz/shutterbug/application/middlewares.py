import re

version_pattern = re.compile(r"/v(?P<version>[0-9a-z\-\+\.]+)", re.IGNORECASE)


class VersionedAPIMiddleware(object):
    """
    Allows a Werkzeug/Flask application to have a versioned API.

    This middleware will extract out the API version specification in a URL
    segment and then forward the processing of the endpoint (sans version), to the
    application along with an environment variable indicating what the version
    requested was.

    If no appropriate version could be parsed, then `None` is set as the
    value of `API_VERSION`.

    """

    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = environ.get('PATH_INFO', '')

        match = version_pattern.match(path)

        if match:
            environ['API_VERSION'] = match.group(1)
            environ['PATH_INFO'] = re.sub(version_pattern, '', path,
                count=1)
        else:
            environ['API_VERSION'] = None

        return self.app(environ, start_response)
