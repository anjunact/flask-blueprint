from flask import g
from flask.ext.restful import Resource, abort, reqparse, url_for
from application import auth, db
from application.models import User
import sqlalchemy

new_user_parser = reqparse.RequestParser()
new_user_parser.add_argument('username', type=str, required=True)
new_user_parser.add_argument('email', type=str, required=True)
new_user_parser.add_argument('password', type=str, required=True)


class SingleUser(Resource):

    method_decorators = [auth.login_required]

    def get(self, user_id):
        """Handling of GET requests."""

        if g.current_user.id != user_id:
            # A user may only access their own user data.
            abort(403, message="You have insufficient permissions"
                " to access this resource.")

        # We could simply use the `current_user`, but the SQLAlchemy identity
        # map makes this a virtual no-op and alos allows for future expansion
        # when users may acess information of other users
        try:
            user = User.query.filter(User.id == user_id).one()
        except sqlalchemy.orm.exc.NoResultFound:
            abort(404, message="No such user exists!")

        data = dict(id=user.id, username=user.username, email=user.email,
                created_on=user.created_on)

        return data, 200


class CreateUser(Resource):

    def post(self):
        """Handling of POST requests."""

        data = new_user_parser.parse_args(strict=True)
        user = User(**data)

        db.session.add(user)

        try:
            db.session.commit()
        except sqlalchemy.exc.IntegrityError:
            abort(409, message="User already exists!")

        data = dict(id=user.id, username=user.username, email=user.email,
                created_on=user.created_on)

        return data, 201, {'Location': url_for('singleuser',
            user_id=user.id, _external=True)}
