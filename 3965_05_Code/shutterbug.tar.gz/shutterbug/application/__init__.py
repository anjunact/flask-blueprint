from flask import Flask, json, make_response
from flask.ext.sqlalchemy import SQLAlchemy
from flask.ext.restful import Api
from flask.ext.bcrypt import Bcrypt
from flask.ext.httpauth import HTTPBasicAuth
from .middlewares import VersionedAPIMiddleware

import os

# Initialize the db extension, but without configuring
# it with an application instance.
db = SQLAlchemy()
api = Api()
flask_bcrypt = Bcrypt()
auth = HTTPBasicAuth()


@api.representation('application/json')
def output_json(data, code, headers=None):
    resp = make_response(json.dumps(data), code)
    resp.headers.extend(headers or {})
    return resp


def create_app(config=None):
    app = Flask(__name__, static_folder=None)
    app.wsgi_app = VersionedAPIMiddleware(app.wsgi_app)

    if config is not None:
        app.config.from_object(config)

    app.config.setdefault('UPLOAD_FOLDER',
        os.path.join(os.path.dirname(__name__), 'uploads'))

    db.init_app(app)
    flask_bcrypt.init_app(app)

    from .resources.photos import SinglePhoto, ListPhoto, UploadPhoto
    from .resources.users import SingleUser, CreateUser
    import authentication

    api.add_resource(ListPhoto, '/photos')
    api.add_resource(UploadPhoto, '/photos')
    api.add_resource(SinglePhoto, '/photos/<int:photo_id>')
    api.add_resource(SingleUser, '/users/<int:user_id>')
    api.add_resource(CreateUser, '/users')

    api.init_app(app)

    return app
